﻿namespace AddressBook.Models
{
    public class ProductModel
    {
        public string Name { get; set; }
        public string Price {get;set;}
        public string Category {get;set;}
        public string Rating { get; set; }

        public string ProductDescription {get;set;}
        public string ProductCompony {get;set;}
    }
}
